﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_customer_login
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txt_username1 = New System.Windows.Forms.TextBox()
        Me.txt_password1 = New System.Windows.Forms.TextBox()
        Me.btn_login = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.date_show_born = New System.Windows.Forms.DateTimePicker()
        Me.txt_show_password = New System.Windows.Forms.TextBox()
        Me.txt_show_username = New System.Windows.Forms.TextBox()
        Me.txt_show_tel = New System.Windows.Forms.TextBox()
        Me.txt_show_address = New System.Windows.Forms.TextBox()
        Me.txt_show_nickname = New System.Windows.Forms.TextBox()
        Me.txt_show_name = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.btn_register = New System.Windows.Forms.Button()
        Me.btn_back = New System.Windows.Forms.Button()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(31, 53)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(43, 17)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Login"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(357, 53)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(61, 17)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Register"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(30, 258)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(73, 17)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Username"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(30, 293)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(69, 17)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Password"
        '
        'txt_username1
        '
        Me.txt_username1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txt_username1.Location = New System.Drawing.Point(121, 255)
        Me.txt_username1.Name = "txt_username1"
        Me.txt_username1.Size = New System.Drawing.Size(139, 30)
        Me.txt_username1.TabIndex = 5
        '
        'txt_password1
        '
        Me.txt_password1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.txt_password1.Location = New System.Drawing.Point(121, 290)
        Me.txt_password1.Name = "txt_password1"
        Me.txt_password1.PasswordChar = Global.Microsoft.VisualBasic.ChrW(35)
        Me.txt_password1.Size = New System.Drawing.Size(139, 30)
        Me.txt_password1.TabIndex = 6
        '
        'btn_login
        '
        Me.btn_login.Location = New System.Drawing.Point(34, 356)
        Me.btn_login.Name = "btn_login"
        Me.btn_login.Size = New System.Drawing.Size(75, 34)
        Me.btn_login.TabIndex = 7
        Me.btn_login.Text = "Login"
        Me.btn_login.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.StarBungs.My.Resources.Resources._5555
        Me.PictureBox1.Location = New System.Drawing.Point(34, 93)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(152, 137)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 4
        Me.PictureBox1.TabStop = False
        '
        'date_show_born
        '
        Me.date_show_born.Location = New System.Drawing.Point(425, 201)
        Me.date_show_born.Name = "date_show_born"
        Me.date_show_born.Size = New System.Drawing.Size(167, 22)
        Me.date_show_born.TabIndex = 83
        '
        'txt_show_password
        '
        Me.txt_show_password.Location = New System.Drawing.Point(722, 155)
        Me.txt_show_password.Name = "txt_show_password"
        Me.txt_show_password.Size = New System.Drawing.Size(140, 22)
        Me.txt_show_password.TabIndex = 82
        '
        'txt_show_username
        '
        Me.txt_show_username.Location = New System.Drawing.Point(722, 111)
        Me.txt_show_username.Name = "txt_show_username"
        Me.txt_show_username.Size = New System.Drawing.Size(140, 22)
        Me.txt_show_username.TabIndex = 81
        '
        'txt_show_tel
        '
        Me.txt_show_tel.Location = New System.Drawing.Point(425, 291)
        Me.txt_show_tel.Name = "txt_show_tel"
        Me.txt_show_tel.Size = New System.Drawing.Size(167, 22)
        Me.txt_show_tel.TabIndex = 80
        '
        'txt_show_address
        '
        Me.txt_show_address.Location = New System.Drawing.Point(425, 247)
        Me.txt_show_address.Name = "txt_show_address"
        Me.txt_show_address.Size = New System.Drawing.Size(436, 22)
        Me.txt_show_address.TabIndex = 79
        '
        'txt_show_nickname
        '
        Me.txt_show_nickname.Location = New System.Drawing.Point(425, 155)
        Me.txt_show_nickname.Name = "txt_show_nickname"
        Me.txt_show_nickname.Size = New System.Drawing.Size(167, 22)
        Me.txt_show_nickname.TabIndex = 78
        '
        'txt_show_name
        '
        Me.txt_show_name.Location = New System.Drawing.Point(425, 111)
        Me.txt_show_name.Name = "txt_show_name"
        Me.txt_show_name.Size = New System.Drawing.Size(167, 22)
        Me.txt_show_name.TabIndex = 71
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(643, 158)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(69, 17)
        Me.Label9.TabIndex = 77
        Me.Label9.Text = "Password"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(643, 114)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(73, 17)
        Me.Label8.TabIndex = 76
        Me.Label8.Text = "Username"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(360, 294)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(55, 17)
        Me.Label7.TabIndex = 75
        Me.Label7.Text = "เบอร์โทร"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(360, 250)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(30, 17)
        Me.Label6.TabIndex = 74
        Me.Label6.Text = "ที่อยู่"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(358, 201)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(44, 17)
        Me.Label5.TabIndex = 73
        Me.Label5.Text = "วันเกิด"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(358, 158)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(43, 17)
        Me.Label10.TabIndex = 72
        Me.Label10.Text = "ชื่อเล่น"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(358, 114)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(45, 17)
        Me.Label11.TabIndex = 70
        Me.Label11.Text = "ชื่อสกุล"
        '
        'btn_register
        '
        Me.btn_register.Location = New System.Drawing.Point(496, 356)
        Me.btn_register.Name = "btn_register"
        Me.btn_register.Size = New System.Drawing.Size(75, 34)
        Me.btn_register.TabIndex = 84
        Me.btn_register.Text = "Register"
        Me.btn_register.UseVisualStyleBackColor = True
        '
        'btn_back
        '
        Me.btn_back.Location = New System.Drawing.Point(640, 356)
        Me.btn_back.Name = "btn_back"
        Me.btn_back.Size = New System.Drawing.Size(75, 34)
        Me.btn_back.TabIndex = 85
        Me.btn_back.Text = "Back"
        Me.btn_back.UseVisualStyleBackColor = True
        '
        'frm_customer_login
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(871, 450)
        Me.Controls.Add(Me.btn_back)
        Me.Controls.Add(Me.btn_register)
        Me.Controls.Add(Me.date_show_born)
        Me.Controls.Add(Me.txt_show_password)
        Me.Controls.Add(Me.txt_show_username)
        Me.Controls.Add(Me.txt_show_tel)
        Me.Controls.Add(Me.txt_show_address)
        Me.Controls.Add(Me.txt_show_nickname)
        Me.Controls.Add(Me.txt_show_name)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.btn_login)
        Me.Controls.Add(Me.txt_password1)
        Me.Controls.Add(Me.txt_username1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "frm_customer_login"
        Me.Text = "Customer"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents txt_username1 As TextBox
    Friend WithEvents txt_password1 As TextBox
    Friend WithEvents btn_login As Button
    Friend WithEvents date_show_born As DateTimePicker
    Friend WithEvents txt_show_password As TextBox
    Friend WithEvents txt_show_username As TextBox
    Friend WithEvents txt_show_tel As TextBox
    Friend WithEvents txt_show_address As TextBox
    Friend WithEvents txt_show_nickname As TextBox
    Friend WithEvents txt_show_name As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents btn_register As Button
    Friend WithEvents btn_back As Button
End Class
